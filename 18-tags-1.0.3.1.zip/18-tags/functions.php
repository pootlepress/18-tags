<?php
/**
 * eighteen-tags engine room
 *
 * @package eighteen-tags
 */

/**
 * Initialize all the things.
 */
require get_template_directory() . '/inc/init.php';

add_action('after_switch_theme', 'eighteen_tags_activated');

function eighteen_tags_activated() {
	$slug = get_option( 'stylesheet' );
	$v1_options = get_option( 'theme_mods_18-tags-1.0.0' );
	if ( $v1_options && array( '' ) == get_option( 'theme_mods_' . $slug ) ) {
		update_option( 'theme_mods_' . $slug, $v1_options );
	}

	$ppb_url = admin_url( 'plugin-install.php?tab=plugin-information&plugin=pootle-page-builder&TB_iframe=true' );
	eighteen_tags_add_notice(
		sprintf(
			__( 'Kindly check out the cool %sPootle Page Builder%s Plugin', 'eighteen-tags' ),
			"<a href='$ppb_url' class='thickbox' title='pootle page builder'>", '</a>'
		),
		'plugins'
	);

}

function eighteen_tags_18tags_migrate_notice() {

	if ( isset( $_GET['search'] ) && $_GET['search'] == 'eighteen tags' ) return;

	$class = 'notice is-dismissible notice-warning';
	$message =
		'<p>We are happy to announce that Eighteen tags is now listed in official WordPress plugins directory!<br>' .
		'Please download new Eighteen tags from %1$swordpress.org%2$s to continue enjoying latest updates and new features!</p>' .
		'Your settings will be preserved. <img src="https://s.w.org/images/core/emoji/72x72/1f600.png" style="height: 20px;vertical-align: middle;">';
	$url = admin_url( 'theme-install.php?search=eighteen%20tags' );
	$message = sprintf( $message, "<a href='$url' title='Download Eighteen tags'>", '</a>' );
	printf( '<div class="%1$s"><p>%2$s</p></div>', $class, $message );
}
add_action( 'admin_notices', 'eighteen_tags_18tags_migrate_notice' );

/**
 * Note: Do not add any custom code here. Please use a custom plugin so that your customizations aren't lost during updates.
 * https://github.com/pootlepress/customisations
 */
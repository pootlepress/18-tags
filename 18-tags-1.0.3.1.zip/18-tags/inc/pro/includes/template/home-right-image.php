<?php
include 'home-left-image.php';
?>